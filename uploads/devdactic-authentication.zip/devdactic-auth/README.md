Ionic AngularJS Authentication Project
======================

Example how to implement a simple user/role based authentication system with Ionic.

For guidance check the related tutorial on http://devdactic.com/


Install
========

Just run the ./init.sh and the project is ready to use!
