bower install
cordova plugin add cordova-plugin-console
cordova plugin add cordova-plugin-device
ionic serve --lab
